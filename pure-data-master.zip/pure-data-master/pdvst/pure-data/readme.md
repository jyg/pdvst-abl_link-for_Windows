# pdvstschedlib (external scheduler) for using pure-data inside vst-host

testing in progress with pure-data 0.47-1, compiled with minGW 

# Instructions
put makefile.pdvst ito pure-data/src folder.

run msys from  /src folder, type make -f makefile.pdvst
