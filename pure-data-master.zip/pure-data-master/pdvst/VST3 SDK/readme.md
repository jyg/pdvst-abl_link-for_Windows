# VST3 SDK 
please download from https://www.steinberg.net/en/company/developers.html