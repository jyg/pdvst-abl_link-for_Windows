# abl_link~ is an puredata external for synchro with ableton link protocol.

Source project : https://github.com/libpd/abl_link/tree/master/external

In order to compile for windows, i had to 
-install vc++2015 standalone compiler
-create a custom code:blocks project
because i couldn't use the make command and mingw environment

windows binary is here : http://puredata.info/Members/jyg/software/abl_link%7E
