# pure-data
externals and utilities to use within pure-data framework

1) Externals
* abl_link~ : compilation guidelines and project for building abl_link~ exernal for windows

* pdvst : updated version of j. Sarlo's project for using Pd (and any externals) as vst plugin inside any windows host. (for multiplateform and pd vanilia, see also camomille project https://github.com/pierreguillot/Camomile ) 

2) Abstractions
* rackpd : live music performance project with puredata (tags : dynamic patching, rjdj)


