pd
== 

These are abstractions that you should copy somewhere into your Pd search path. Alternatively 
set the search path to the dirctory where you've downloaded these files to. See
http://en.flossmanuals.net/PureData/AdvancedConfig for details.
